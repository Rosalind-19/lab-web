<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List - MVC</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; padding: 20px;
        }
        .container {
            max-width: 1200px; margin: 0 auto; background: white;
            border-radius: 10px; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 { color: #333; margin-bottom: 10px; font-size: 32px; }
        .subtitle { color: #666; margin-bottom: 30px; font-style: italic; }
        .message { padding: 15px; margin-bottom: 20px; border-radius: 5px; font-weight: 500; }
        .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .btn {
            display: inline-block; padding: 12px 24px; text-decoration: none;
            border-radius: 5px; font-weight: 500; transition: all 0.3s;
            border: none; cursor: pointer; font-size: 14px;
        }
        .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4); }
        .btn-secondary { background-color: #6c757d; color: white; }
        .btn-danger { background-color: #dc3545; color: white; padding: 8px 16px; font-size: 13px; }
        .btn-danger:hover { background-color: #c82333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        thead { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #ddd; }
        th { font-weight: 600; text-transform: uppercase; font-size: 13px; letter-spacing: 0.5px; }
        tbody tr { transition: background-color 0.2s; }
        tbody tr:hover { background-color: #f8f9fa; }
        .actions { display: flex; gap: 10px; }
        .empty-state { text-align: center; padding: 60px 20px; color: #999; }
        .empty-state-icon { font-size: 64px; margin-bottom: 20px; }
        .pagination { margin: 20px 0; text-align: center; }
        .pagination a { padding: 8px 12px; margin: 0 4px; border: 1px solid #ddd; text-decoration: none; color: #333; }
        .pagination strong { padding: 8px 12px; margin: 0 4px; background-color: #4CAF50; color: white; border: 1px solid #4CAF50; border-radius: 4px;}
    </style>
</head>
<body>
    <div class="container">
        <h1>📚 Student Management System</h1>
        <p class="subtitle">MVC Pattern with Jakarta EE & JSTL</p>

        <!-- Success Message -->
        <c:if test="${not empty param.message}">
            <div class="message success">✅ ${param.message}</div>
        </c:if>

        <!-- Error message -->
        <c:if test="${not empty param.error}">
            <div class="message error">❌ ${param.error}</div>
        </c:if>

        <!-- Buttons -->
        <div style="margin-bottom: 20px; display: flex; gap: 10px;">
            <a href="student?action=new" class="btn btn-primary">➕ Add New Student</a>
            <a href="export" class="btn" style="background-color: #28a745; color: white;">📊 Export to Excel</a>
        </div>

        <!-- filter by major -->
        <div class="filter-box" style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; background-color: #f9f9f9;">
            <h3 style="margin-bottom: 15px; color: #333;">🎯 Filter by Major</h3>
            <form action="student" method="get" style="display: flex; gap: 10px; align-items: center;">
                <input type="hidden" name="action" value="filter">

                <select name="major" style="flex: 1; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    <option value="">All Majors</option>
                    <option value="Computer Science" ${selectedMajor == 'Computer Science' ? 'selected' : ''}>Computer Science</option>
                    <option value="Information Technology" ${selectedMajor == 'Information Technology' ? 'selected' : ''}>Information Technology</option>
                    <option value="Software Engineering" ${selectedMajor == 'Software Engineering' ? 'selected' : ''}>Software Engineering</option>
                    <option value="Business Administration" ${selectedMajor == 'Business Administration' ? 'selected' : ''}>Business Administration</option>
                </select>

                <button type="submit" style="padding: 8px 15px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Apply Filter
                </button>

                <c:if test="${not empty selectedMajor}">
                    <a href="student?action=list" style="padding: 8px 15px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 4px;">
                        ✖ Clear Filter
                    </a>
                </c:if>
            </form>
        </div>

        <!-- search student -->
        <div class="search-box" style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; background-color: #f9f9f9;">
             <h3 style="margin-bottom: 15px; color: #333;">🔍 Search Student</h3>
             <form action="student" method="get" style="display: flex; gap: 10px; align-items: center;">
                 <input type="hidden" name="action" value="search">
                 <input type="text" name="keyword" value="${keyword}" placeholder="Search by code, name, or email..." style="flex: 1; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                 <button type="submit" style="padding: 8px 15px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">🔍 Search</button>
                 <c:if test="${not empty keyword}">
                     <a href="student?action=list" style="padding: 8px 15px; background-color: #6c757d; color: white; text-decoration: none; border-radius: 4px;">✖ Clear</a>
                 </c:if>
             </form>
        </div>

        <!-- Search results message -->
        <c:if test="${not empty keyword}">
             <div style="margin: 10px 0; padding: 10px; background-color: #e7f3ff; border-left: 4px solid #007bff;">
                 Search results for: <strong>"${keyword}"</strong>
             </div>
        </c:if>

        <!-- Student Table -->
        <c:choose>
            <c:when test="${not empty students}">
                <table>
                    <thead>
                        <tr>
                            <th><a href="student?action=sort&sortBy=id&order=asc" style="color: white; text-decoration: none;">ID</a></th>
                            <th>Photo</th>
                            <th><a href="student?action=sort&sortBy=student_code&order=asc" style="color: white; text-decoration: none;">Student Code</a></th>
                            <th><a href="student?action=sort&sortBy=full_name&order=asc" style="color: white; text-decoration: none;">Full Name</a></th>
                            <th><a href="student?action=sort&sortBy=email&order=asc" style="color: white; text-decoration: none;">Email</a></th>
                            <th>Major</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="student" items="${students}">
                            <tr>
                                <td>${student.id}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${not empty student.photo}">
                                            <img src="uploads/${student.photo}" alt="Avatar" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; border: 1px solid #ddd;">
                                        </c:when>
                                        <c:otherwise>
                                            <div style="width: 50px; height: 50px; background: #eee; border-radius: 5px; display: flex; align-items: center; justify-content: center; font-size: 20px;">👤</div>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td><strong>${student.studentCode}</strong></td>
                                <td>${student.fullName}</td>
                                <td>${student.email}</td>
                                <td>${student.major}</td>
                                <td>
                                    <div class="actions">
                                        <a href="student?action=edit&id=${student.id}" class="btn btn-secondary">✏️ Edit</a>
                                        <a href="student?action=delete&id=${student.id}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this student?')">🗑️ Delete</a>
                                    </div>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>

                <!-- Phân trang -->
                <div class="pagination">
                    <!-- Previous button -->
                    <c:if test="${currentPage > 1}">
                        <a href="student?action=list&page=${currentPage - 1}&keyword=${keyword}&major=${selectedMajor}&sortBy=${sortBy}&order=${order}" class="btn">« Previous</a>
                    </c:if>

                    <!-- Page numbers -->
                    <c:forEach begin="1" end="${totalPages}" var="i">
                        <c:choose>
                            <c:when test="${i == currentPage}">
                                <strong>${i}</strong>
                            </c:when>
                            <c:otherwise>
                                <a href="student?action=list&page=${i}&keyword=${keyword}&major=${selectedMajor}&sortBy=${sortBy}&order=${order}">${i}</a>
                            </c:otherwise>
                        </c:choose>
                    </c:forEach>

                    <!-- Next button -->
                    <c:if test="${currentPage < totalPages}">
                        <a href="student?action=list&page=${currentPage + 1}&keyword=${keyword}&major=${selectedMajor}&sortBy=${sortBy}&order=${order}" class="btn">Next »</a>
                    </c:if>
                </div>
                <p style="text-align: center; margin-top: 10px;">Showing page ${currentPage} of ${totalPages}</p>

            </c:when>
            <c:otherwise>
                <div class="empty-state">
                    <div class="empty-state-icon">📭</div>
                    <h3>No students found</h3>
                    <p>Start by adding a new student</p>
                </div>
            </c:otherwise>
        </c:choose>
    </div>
</body>
</html>