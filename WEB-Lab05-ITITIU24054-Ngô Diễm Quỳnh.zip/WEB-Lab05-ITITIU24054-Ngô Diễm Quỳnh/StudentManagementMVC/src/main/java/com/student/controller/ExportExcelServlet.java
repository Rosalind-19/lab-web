package com.student.controller;


import com.student.dao.StudentDAO;
import com.student.model.Student;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.util.List;

@WebServlet("/export")
public class ExportExcelServlet extends HttpServlet {

    private StudentDAO studentDAO;

    @Override
    public void init() {
        studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ______ láy danh sách sinh viên ______
        List<Student> students = studentDAO.getAllStudents();

        // ______ tạo workbook ______
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Students");

        // ______ tạo header style ______
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        // ______ tạo header row ______
        Row headerRow = sheet.createRow(0);
        String[] columns = {"ID", "Student Code", "Full Name", "Email", "Major", "Created At"};

        for (int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerStyle);
        }

        // ______ điền dữ liệu dô ______
        int rowNum = 1;
        for (Student student : students) {
            Row row = sheet.createRow(rowNum++);

            row.createCell(0).setCellValue(student.getId());
            row.createCell(1).setCellValue(student.getStudentCode());
            row.createCell(2).setCellValue(student.getFullName());
            row.createCell(3).setCellValue(student.getEmail());
            row.createCell(4).setCellValue(student.getMajor());
            row.createCell(5).setCellValue(student.getCreatedAt().toString());
        }

        // ______ auto-size column ______
        for (int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // ______ respnose header ______
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=students.xlsx");

        // ______ write output stream ______
        workbook.write(response.getOutputStream());
        workbook.close();
    }
}