STUDENT INFORMATION:
Name: Ngô Diễm Quỳnh
Student ID: ITITIU24054
Class: Web Application Development_S2_2025-26_G01_lab02

COMPLETED EXERCISES:
[x] Exercise 5: Search
[x] Exercise 6: Validation
[x] Exercise 7: Sorting & Filtering
[x] Exercise 8: Pagination
[x] Bonus 1: Export Excel
[x] Bonus 2: Photo Upload
[x] Bonus 3: Combined Search + Filter + Sort

MVC COMPONENTS:
- Model: Student.java
- DAO: StudentDAO.java
- Controller: StudentController.java
- Views: student-list.jsp, student-form.jsp

FEATURES IMPLEMENTED:
- All CRUD operations
- Search functionality
- Server-side validation
- Sorting by columns
- Filter by major

KNOWN ISSUES:
- None

EXTRA FEATURES:
- No extra features

TIME SPENT: 14 hours