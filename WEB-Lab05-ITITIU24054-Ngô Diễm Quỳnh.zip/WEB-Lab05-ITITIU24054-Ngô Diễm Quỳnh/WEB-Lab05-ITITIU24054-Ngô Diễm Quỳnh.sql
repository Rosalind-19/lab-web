CREATE DATABASE IF NOT EXISTS student_management;
USE student_management;
DROP TABLE IF EXISTS students;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_code VARCHAR(20) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    major VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    photo VARCHAR(255)
);

INSERT INTO students (student_code, full_name, email, major)
VALUES 
('SV001', 'Nguyen Van A', 'a@gmail.com', 'Information Technology'),
('SV002', 'Tran Thi B', 'b@gmail.com', 'Business Administration'),
('SV003', 'Le Van C', 'c@gmail.com', 'Computer Science');